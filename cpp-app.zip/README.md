# C++ Calculator App

This is a simple calculator written in C++. It supports addition, subtraction, multiplication, and division.

## Build

```bash
make
```

## Run

```bash
./app
```

## Clean

```bash
make clean
```
